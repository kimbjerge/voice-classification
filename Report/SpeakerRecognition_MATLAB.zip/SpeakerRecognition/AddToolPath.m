addpath('C:\IHA\TINONS1\HMMall\KPMtools')
addpath('C:\IHA\TINONS1\HMMall\KPMstats')
addpath('C:\IHA\TINONS1\voicebox');
addpath('C:\IHA\TINONS1\prtools');
addpath('C:\IHA\TINONS1\netlab');
